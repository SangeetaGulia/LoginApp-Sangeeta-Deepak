package controllers

import play.api.mvc.Action
import play.api.data._
import play.api.i18n.Messages.Implicits._
import play.api.Play.current
import play.api.data.Forms._
import play.api.mvc._
import play.api.mvc.Action

/**
  * Created by knodus on 29/2/16.
  */

class AccountController extends Controller{

  def showAccountsPage()=Action{
    implicit request =>
      request.session.get("email").map { user =>
        Ok(views.html.accountsPage(user))
      }.getOrElse {
        Unauthorized("Oops, you are not connected")
      }
  }


  def logout = Action {  request =>
    Ok(views.html.logout()).withNewSession
  }

}
